HDP BALAP MOBIL 3D
Sumber index.html adalah file HDP_Balap_3D.html yang diunggah pengguna.
Ikon berasal dari gambar resmi HDP Balap Mobil 3D yang diunggah pengguna; ikon foreground dipasang penuh 1024x1024 tanpa diperkecil ke dalam kanvas.
