# HDP BILIAR 8 — Paket Proyek Lengkap

Brand: HDP Hadiansyah DigitalPreneur

## Build APK
Workflow Android: `.github/workflows/android-apk.yml`

Workflow ini disimpan di ZIP sebagai sumber salinan. Untuk menjalankannya, workflow harus terlebih dahulu dibuat/di-commit di repository GitHub pada path yang sama. Setelah itu unggah ZIP ini ke root repository dengan nama `HDP_BILIAR_8_FULL_PROJECT.zip`. Workflow akan mengekstraknya otomatis dan membangun `app-debug.apk` sebagai artifact.

APK yang dihasilkan adalah APK debug untuk uji coba, bukan rilis Play Store.
