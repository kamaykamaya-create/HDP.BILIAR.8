# HDP Biliar 8-Ball

**Brand:** HDP Hadiansyah DigitalPreneur

## Isi paket
- `index.html` — game HTML sumber dengan metadata PWA.
- `icons/` — ikon aplikasi 192 px, 512 px, dan Apple Touch Icon.
- `manifest.webmanifest` — identitas aplikasi.
- `sw.js` — cache aplikasi dan pustaka Three.js untuk pemakaian offline setelah instalasi/cache pertama.
- `.github/workflows/pages.yml` — workflow build dan deployment otomatis.

## Cara build melalui HP
1. Buat repository GitHub baru.
2. Unggah seluruh isi ZIP ini ke root repository, termasuk folder `.github`.
3. Pastikan nama branch utama `main`.
4. Buka tab **Actions**. Workflow akan mengambil Three.js r128, lalu menerbitkan situs ke GitHub Pages.
5. Buka **Settings → Pages** jika perlu memastikan deployment menggunakan GitHub Actions.
6. Setelah workflow berhasil, buka URL Pages dari HP Android melalui Chrome. Gunakan menu browser **Install app / Add to Home screen**.

## Mode offline
Setelah deployment berhasil, buka aplikasi sekali saat online agar service worker dapat menyimpan HTML, ikon, manifest, dan `three.min.js`. Setelah cache selesai, aplikasi dapat dibuka kembali offline. Pengujian offline tetap perlu dilakukan pada HP.

## Catatan
Mekanika permainan dalam HTML sumber tidak sengaja diubah. Penambahan hanya mencakup identitas PWA, ikon, manifest, service worker, serta workflow pengambilan dependensi dan deployment.
