HDP BALAP 3D - APK PACKAGE
Brand: HDP Hadiansyah DigitalPreneur

Upload this ZIP file directly to the existing GitHub repository root.
Do not extract it manually on the phone.
Keep the existing workflow file unchanged.
The workflow extracts HDP.BILIAR.8.zip, prepares the Android project,
generates Android launcher icons from assets/icon-only.png, and builds app-debug.apk.

Game source: index.html (preserved from HDP_BALAP_GAME.html)
App icon source: assets/icon-only.png
